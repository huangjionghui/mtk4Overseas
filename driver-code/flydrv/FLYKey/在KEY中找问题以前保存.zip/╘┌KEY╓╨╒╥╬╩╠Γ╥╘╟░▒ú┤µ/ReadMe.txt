////////////////////////////////////////////////////////////////////////

FEATURE NAME:



MANUFACTURER:



CONTACT INFO:



DATE:



VERSION:



SIZE:



DESCRIPTION:



NOTES:



////////////////////////////////////////////////////////////////////////


========================================================================
       DYNAMIC LINK LIBRARY : FLY7730
========================================================================


The Subproject Wizard has created this FLY7730 DLL for you.  

This file contains a summary of what you will find in each of the files that
make up your FLY7730 application.

FLY7730.pbpxml
    This file contains information at the subproject level and
    is used to build a single subproject for an OS design.
    Other users can share the subproject (.pbpxml) file.

FLY7730.cpp
    This is the main DLL source file.

    This DLL does not export any symbols, so it will not produce 
    a .lib file when it is built. If you want this subproject to 
    be a dependency of another OS design or subproject, add code 
    to export symbols in this .dll file to produce an export library. 

/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named FLY7730.pch and a precompiled types file named StdAfx.obj.


/////////////////////////////////////////////////////////////////////////////
Other notes:

The Subproject Wizard uses "TODO:" to indicate parts of the source code you
should add to or customize.


/////////////////////////////////////////////////////////////////////////////
